clc;

% parameters
Vref = 1; % Reference voltage
B = 10; % Number of bits
N = 1024; % number of samples
m = 497;
A =1;
n = (0:N-1);
input_signal = A/2 + (A/2)*sin((2*pi*m*n)/1024); 
sigma_mismatch = 0.0005;  % Standard deviation of mismatch
ideal_caps = [2.^(B-1:-1:0) * 1, 1];
C_mismatch = ideal_caps .* (1 + sigma_mismatch * randn(size(ideal_caps)));

%% 

% Initialize arrays to store SNR results and output mismatch
snr_ideal_values = zeros(1, 50);
snr_mismatch_values = zeros(1, 50);
%output_mismatch_all = cell(1, 50);

for k = 1:100
    % Generate Mismatched Capacitor Array
    C_mismatch = ideal_caps .* (1 + sigma_mismatch * randn(size(ideal_caps)));
    
    % SAR ADC Simulation with Ideal and Mismatched Capacitors
    output_ideal = SAR_simulation_fun(input_signal, Vref,B,ideal_caps);
    output_mismatch = SAR_simulation_fun(input_signal,Vref,B, C_mismatch);
    %output_mismatch_all{k} = output_mismatch;
    
    % Calculate SNR
    snr_ideal_values(k) = SNR_calculator(output_ideal,m,N);
    snr_mismatch_values(k) = SNR_calculator(output_mismatch, m,N);

end

% Calculate mean and standard deviation of SNR values
mean_snr_ideal = mean(snr_ideal_values)
std_snr_ideal = std(snr_ideal_values);
mean_snr_mismatch = mean(snr_mismatch_values)
std_snr_mismatch = std(snr_mismatch_values);

figure(1);
histogram(snr_mismatch_values, 'BinWidth', 0.2);
title('SNR Distribution with Mismatched Capacitors');
xlabel('SNR (dB)');
ylabel('Frequency');

%%Results 
% at sigma = 1.5e-04 ,the mean_snr_mismatch is 62.0603 and ideal_snr is 62.0761
% at sigma = 5e-04, the mean_snr_mismatch is 61.84 and ideal_snr is 62.0761
% at sigma = 1e-03, the mean_snr_mismatch is 61.1546 and ideal_snr is 62.0761


