clc;

% parameters
Vref = 1; % Reference voltage
B = 11; % Number of bits
N = 1024; % number of samples
m = 29;
A =1;
n = (0:N-1);
input_signal = A/2 + (A/2)*sin((2*pi*m*n)/1024); 
noise_stddev = 0 ;%0.000167; % input noise reffered for comparator
sigma_mismatch = 0.0002;  % Standard deviation of mismatch
ideal_caps = [2.^(B-1:-1:0) * 1, 1];
C_mismatch = ideal_caps .* (1 + sigma_mismatch * randn(size(ideal_caps)));

%% 

% Initialize arrays to store SNR results and output mismatch
snr_values = zeros(1, 50);
snr_mismatch_values = zeros(1, 50);

for k = 1:100

    % Generate Mismatched Capacitor Array
    C_mismatch = ideal_caps .* (1 + sigma_mismatch * randn(size(ideal_caps)));
   
    % SAR ADC Simulation with Ideal Capacitors
    output_ideal = SARsimulationwithcompnoise(input_signal, Vref,B,ideal_caps,noise_stddev);
    output_mismatch = SARsimulationwithcompnoise(input_signal,Vref,B, C_mismatch, noise_stddev);
    % Calculate SNR
    snr_values(k) = SNR_calculator(output_ideal,m,N);
    snr_mismatch_values(k) = SNR_calculator(output_mismatch, m,N);

end

% Calculate mean and standard deviation of SNR values
mean_snr_ideal = mean(snr_values)
std_snr_ideal = std(snr_values);
mean_snr_mismatch = mean(snr_mismatch_values)
std_snr_mismatch = std(snr_mismatch_values);

figure(1);
histogram(snr_values, 'BinWidth', 0.2);
title('SNR Distribution');
xlabel('SNR (dB)');
ylabel('Frequency');


figure(2);
histogram(snr_mismatch_values, 'BinWidth', 0.2);
title('SNR Distribution_withmismatch');
xlabel('SNR (dB)');
ylabel('Frequency');


