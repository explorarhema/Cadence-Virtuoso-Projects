clc ; clear all;
DATA  = importdata("mdsm477.mat");
N = 16384;
DATA = table2array(DATA);

D = DATA./1.8;
D = D(:,2);
D = D(1:10:end);
figure(1);
plot(D);
axis tight;
D =D(1:N);
% V2 =hann(N);
% V = D.*V2;
hannwindow = 1-cos(2*pi*(0:N-1)/N);
V1 = D.*hannwindow';
pxx = pwelch(D,rectwin(N),[],N);
figure(2);
plot(10*log10(pxx));
pxx1 = pwelch(V1,rectwin(N),[],N);
figure(3);
plot(10*log10(pxx1));
A  = pxx(8);
B = sum(pxx(1:N/256)) - pxx(1) - pxx(8);
SNR = 10*log10(A/B)
A_hann = pxx1(7) + pxx1(8) + pxx1(9);
B_hnn = sum(pxx1(1:N/256)) - (pxx1(1) + pxx1(2) + pxx1(7) + pxx1(8) + pxx1(9));
SNR_hnn = 10*log10(A_hann/B_hnn)
%  ft = abs(fft(D,N));
%  vt = abs(fft(V,N));
%  figure(2);
%  plot(20*log10(vt(3:end)));
%  figure(3);
%  plot(20*log10(ft(2:end)));
% psd = ft(2:N/2).^2;
% PSD_V = vt(3:N/2).^2;
% figure(4);
% stem(pow2db(psd));
% figure(5);
% stem(pow2db(PSD_V));
% figure(6);
% plot(pow2db(psd));
% figure(7);
% plot(pow2db(PSD_V));
% a = psd(7);
% b = sum(psd(1:(N/256))) - psd(7);
% SNR = 10*log10(a/b)
% a1 = PSD_V(5)+PSD_V(6)+PSD_V(7);
% b1 = sum(PSD_V(1:N/256)) - a1;
% SNR_hann = 10*log10(a1/b1)

%% Results 
% f_s = 1/T_s = 1/(2.92968750000000e-08) =34MHz
% f_0 = (7/16384)*f_s =14.58KHz
% Bins at 7 and 16377
% ADC should run for 16384*T_s ~ 0.5msec Transient time to get 16384 DFT points 
% SNR obtained with and without windowing are 93.75 and 83.507 respectively

