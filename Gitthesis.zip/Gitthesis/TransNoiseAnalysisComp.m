clc ; clear all;
DATA  = importdata("TNACompaW20M10.mat");
DATA = table2array(DATA);

D = DATA;
D = D(:,2);
D = D(1:10:end);
D = D(2:end);
one_count = 0;
zero_count = 0;
for i = 1:length(D)
    if D(i) > 0 
       one_count = one_count + 1; 
    end
    if D(i) < 0
        zero_count = zero_count +1;
    end
end