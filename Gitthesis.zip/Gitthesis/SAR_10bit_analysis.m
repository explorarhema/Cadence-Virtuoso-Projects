clc ; clear all;
SARDATA  = importdata("SAR_nonidealpmoscomp.mat");
N = 1024;
SARDATA = table2array(SARDATA);
%SARDATA = SARDATA./0.9;
D = SARDATA(:,11) + 2*SARDATA(: ,10) + 4*SARDATA(: ,9) + 8*SARDATA(: ,8)+ 16*SARDATA(: ,7)+ 32*SARDATA(: ,6)+ 64*SARDATA(: ,5)+128*SARDATA(: ,4)+ 256*SARDATA(: ,3)+ 512*SARDATA(: ,2);
figure(1);
plot(D);
axis tight;
ft = abs(fft(D(2:1030),N));
figure(2);
stem (ft);
axis tight;
figure(4);
stem(((0:1023)/1024)*10^7,ft);grid
 PSD1 = ft(2:N/2).^2;

 %%
%PSD = pwelch(D) ;
PSD = sort(PSD1, 'descend');
figure(3);
stem(PSD);
axis tight;
a = PSD(1);
b = sum(PSD(2:end));
10*log10(a/b)
psd_dB = 10*log10(PSD);
figure(5);
stem(psd_dB);
figure(6);
plot(pow2db(PSD1));


% D1 = 2*(D/1024)-1;
% ft1 = abs(fft(D1(2:1030),N));
%  PSD2 = ft1(2:N/2).^2;
%  figure(7); plot(10*log10(PSD2/N));


