function decimal_outputs= SAR_simulation_fun(analog_inputs, Vref, D, capacitors)
    % SAR ADC simulation 
    % analog_inputs: array of input analog signals (between 0 and Vref)
    % Vref: reference voltage
    % D: number of bits of the ADC
    % capacitors: array of capacitor values 
    
    % Number of samples
    N = length(analog_inputs);
    
    % Initialize variables
    digital_outputs = zeros(N, D);
    decimal_outputs = zeros(N, 1);
    Vfs = Vref; % Full-scale voltage
    capacitor_sum = sum(capacitors); % Total capacitance
    
    % SAR conversion process for each sample
    for j = 1:N
        analog_input = analog_inputs(j);
        dac_output = 0; % Reset DAC output for each sample
        for i = 1:D
            % Set the i-th bit 
            dac_output = dac_output + (capacitors(i) / capacitor_sum) * Vfs;
            % Compare DAC output with analog input
            if analog_input >= dac_output
                % i-th bit set to 1
                digital_outputs(j, i) = 1;
            else
                % Clear the bit and revert the DAC output
                dac_output = dac_output - (capacitors(i) / capacitor_sum) * Vfs;
                digital_outputs(j, i) = 0;
            end
        end
        % Convert binary digital output to decimal
        decimal_outputs(j) = bin2dec(num2str(digital_outputs(j, :)));
    end
end