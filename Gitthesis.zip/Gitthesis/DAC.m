clc; clear all;

% Example input binary output from ADC
%binaryoutput = [0     0     0     1     0     1     1     1     0     0];
decimalNumber = 313;
binaryString = dec2bin(decimalNumber, 10)
charVector = binaryString(:)'
binaryoutput = charVector - '0'

% Define the high and low reference voltages
high = 1;
low = -1;

% Convert the binary output back to analog
analogValue = logic(binaryoutput, high, low)

function analogValue = logic(binaryoutput, high, low)
    bits = length(binaryoutput);
    analogValue = 0;

    for i = 1:bits
        mid = (high + low) / 2;
        if binaryoutput(i) == 1
            low = mid;
        else
            high = mid;
        end
    end

    analogValue = (high + low) / 2;
end



