clc ; clear all;
Vin = -0.9967;
high  = 1;
low = -1;
bits = 10;

binaryoutput = Search(Vin, high,low,bits)

function binaryoutput = Search(Vin, high,low,bits)
   binaryoutput = zeros(1, bits);
    for i = 1:bits
        mid = (high + low)/2;
        if (Vin>mid)
            binaryoutput(i) = 1;
            low = mid;
        else
            binaryoutput(i) = 0;
            high = mid;
        end

    end

end