clc; clear all; close all;

% Define initial values for P1 < P2
G1 = 1;
G2 = 15;
C1 = 1;
C2 = 5; %C2>C1

% Define Gm (arbitrarily chosen for the example)
Gm = 50;

% Range of Cc values
Cc_values = linspace(0, 10, 100);

% Preallocate arrays for poles
P1_original = G1 / C1;
P2_original = G2 / C2;

P1_new = zeros(size(Cc_values));
P2_new = zeros(size(Cc_values));

% Compute new poles for varying Cc
for i = 1:length(Cc_values)
    Cc = Cc_values(i);
    P1_new(i) = G1 / (C1 + Cc * (Gm / G2));
    P2_new(i) = (G2 + Gm * (Cc / (Cc + C1))) / (C2 + ((C1 * Cc) / (C1 + Cc)));
end

% Plot the pole movements for P1 < P2
figure;
plot(Cc_values, P1_new, 'b', 'LineWidth', 2);
hold on;
plot(Cc_values, P2_new, 'r', 'LineWidth', 2);
xlabel('Cc');
ylabel('Poles');
title('Pole Movements for P1 < P2');
legend('P1', 'P2');
grid on;

% Plot the pole movements for P1 > P2 (Swap G1 and G2)
G1 = 5;
G2 = 1;
P1_original = G1 / C1;
P2_original = G2 / C2;
P1_new1 = zeros(size(Cc_values));
P2_new1 = zeros(size(Cc_values));

for i = 1:length(Cc_values)
    Cc = Cc_values(i);
    P1_new1(i) = G1 / (C1 + Cc * (Gm / G2));
    P2_new1(i) = (G2 + Gm * (Cc / (Cc + C1))) / (C2 + ((C1 * Cc) / (C1 + Cc)));
end

figure;
plot(Cc_values, P1_new1, 'b', 'LineWidth', 2);
hold on;
plot(Cc_values, P2_new1, 'r', 'LineWidth', 2);
xlabel('Cc');
ylabel('Poles');
title('Pole Movements for P1 > P2');
legend('P1', 'P2');
grid on;
