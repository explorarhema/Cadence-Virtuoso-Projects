
function snr_value = SNR_calculator(decimal_outputs,m ,N)

    D = decimal_outputs;  
    pxx = pwelch(D,rectwin(N),[],N); % window is rect so that PSD wont chnge
    a  = pxx(m+1);  % signal power
    b = sum(pxx) - pxx(1) - pxx(m+1);% noise power % pxx(1) is DC bin 
    snr_value = 10*log10(a/b);

end

