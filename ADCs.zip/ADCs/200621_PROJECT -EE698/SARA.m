clc ; clear all;
SARDATA  = importdata("FINALSARDATA.mat");
N = 1024;
SARDATA = table2array(SARDATA);
x = SARDATA(:,8) ;
SARDATA = SARDATA./0.9;
D = SARDATA(:,2) + 2*SARDATA(: ,3) + 4*SARDATA(: ,4) + 8*SARDATA(: ,5)+ 16*SARDATA(: ,6)+ 32*SARDATA(: ,7)+ 64*SARDATA(: ,8);
figure(1);
plot(D);
ft = abs(fft(D(2:end),N));
figure(2);
stem (ft);
 PSD = ft(2:N/2).^2;
%PSD = pwelch(D) ;
PSD = sort(PSD, 'descend');
figure(3);
stem(PSD);
a = PSD(1);
b = sum(PSD(2:end));
10*log(a/b)


